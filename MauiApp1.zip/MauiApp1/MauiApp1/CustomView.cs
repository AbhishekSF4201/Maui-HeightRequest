﻿using Microsoft.Maui.Layouts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiApp1
{
    public class CustomView : ControlLayout
    {
        public CustomView()
        {
            this.Children.Add(new Label() { Text = "Hello World" });
        }

        protected override ILayoutManager CreateLayoutManager()
        {

            return new ControlLayoutManager(this);
        }

        internal override Size ArrangeContent(Rect bounds)
        {
            this.Children[0].Arrange(bounds);
            return bounds.Size;
        }

        internal override Size MeasureContent(double widthConstraint, double heightConstraint)
        {
            this.Children[0].Measure(100, 50);
            return new Size(widthConstraint, heightConstraint);
        }
    }

    public abstract class ControlLayout : Layout
    {
        internal abstract Size ArrangeContent(Rect bounds);

        internal abstract Size MeasureContent(double widthConstraint, double heightConstraint);
    }

    internal class ControlLayoutManager : LayoutManager
    {
        ControlLayout layout;
        internal ControlLayoutManager(ControlLayout layout) : base(layout)
        {
            this.layout = layout;
        }

        public override Size ArrangeChildren(Rect bounds) => this.layout.ArrangeContent(bounds);

        public override Size Measure(double widthConstraint, double heightConstraint) => this.layout.MeasureContent(widthConstraint, heightConstraint);
    }
}
